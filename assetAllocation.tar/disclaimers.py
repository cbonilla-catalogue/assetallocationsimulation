import dash_design_kit as ddk
from dash import html

footer = ddk.PageFooter(
    "INSIGNEO, LLC This presentation is for informational purposes only for the inteded use of the specified recipient together with their advisor."
)

def addDisclaimers(business):
    if business == 'Advisory':
            return [ddk.Page(
                [
                    html.H2("Important Disclosures & Disclaimers - Regarding Proposed Expected Portfolio Returns"),
                    html.H3("Notes on calculating portfolio expected performance and capital market expectations"),
                    html.P(
                        """
                The expected return must be viewed as part of the description of the entire distribution (assuming a quadratic distribution). Viewed alone, it measures the mean of the entire
distribution of future outcomes. It may never be achieved as an outcome at all. The standard deviation portrays the dispersion of possible outcomes around the expected return.
To decide whether it makes sense to invest in an asset class, these elements must be viewed together, and compared with the nature of other asset classes. Each input viewed
alone is insufficient for solving the portfolio selection problem.
                """
                    ),
                    html.P(
                        """
                Using Morningstar's Direct Asset Allocation tool, we generate historical statistics of asset classes that we believe encompass most risk premia in an investment portfolio using
market indices chosen based on their available data and stated investment universe. We call these available risk premia risk asset classes. Historical estimates will tell us what
has happened while forecasted estimates will tell us what we expect to occur. While there may be reasons to expect the future to repeat the past, historical inputs can be very
time dependent and unstable as large structural or regulatory changes may change how these asset classes behave. For example, the S&P 500 has performed between 36.12%
and –17.36 percent over a 5-year holding period between 1926 and 2001. If you were to model the expected return with S&P 500 for a five-year investment horizon, there would be a
large range of values that you could select from.
                """
                    ),
                    html.P(
                        """
                In addition to using historical returns and user-specified returns, Direct Asset Allocation provides three models for developing expected returns for these risk asset classes:
Building Blocks, CAPM (Capital Asset Pricing Model), and Black-Litterman. Building Blocks and CAPM calculate forward-looking expected returns based on historical risk
premiums and the current market condition. In both methods, the expected return is calculated by adding together historical risk premium(s) and the current risk-free rate.
Historical risk premiums are preferred over standard historical calculations since risk premiums have been found to be more consistent and stable over time. With the relative
stable nature of risk premiums, you have more confidence predicting future returns. The major difference between Building Blocks and CAPM is in the risk premium calculation.
Building Blocks calculates risk premium(s) by taking the arithmetic difference between two historical data series, while CAPM uses a regression approach. The third model, the
Black-Litterman method is a powerful and flexible model for creating a set of expected returns that in turn result in asset allocations that can be used in the real world. It can also
incorporate a user's forward-looking views of the market in the expected returns. A set of implied returns for each asset class are first calculated from a given risk-free rate,
market risk premium, and a set of market capitalization weights before the views are applied to arrive at the Black-Litterman expected returns for each asset class. We match the
appropriate risk asset class with the model best explaining the historical characteristics and any expected deviations from history. For example, we use the building block model
for EUR denominated debt because it allows us to model the negative rate environment since the financial crisis that would not be apparent in a historical forecast analysis.
                """
                    ),
                    footer,
                ]
            ),
            ddk.Page(
                [
                    html.H2("DISCLAIMERS"),
                    html.P(
                        """
                This material is intended only to facilitate general discussions and is not intended as a source of any specific recommendation for a specific individual.Please consult with your account executive or financial advisor if any specific recommendation made herein is right for you.This does not constitute an offer or solicitation with respect to the purchase or sale of any security in any jurisdiction in which such an offer orsolicitation is not authorized or to any person to whom it would be unlawful to make such an offer or solicitation. . Brokerage and investment advisoryaccount investments are subject to market risk including loss of principal. Insigneo Securities, LLC (Insigneo)) is a broker/dealer registered with the U.SSecurities and Exchange Commission (SEC) and a member of the Financial Industry Regulatory Authority (FINRA) and Securities Investors ProtectionCorporation (SIPC). Insigneo is affiliated to two U.S. registered investment advisors, Insigneo Wealth Advisors, LLC (IWA) and Insigneo AdvisoryServices, LLC (IAS). Collectively, we refer to Insigneo, IAS, and IWA as the Insigneo Financial Group. To learn more about their business, including theirconflicts of interest and compensation practices for the Broker Dealer please go to www.insigneo.com/en/disclosures and any conflicts related to theiradvisory services, please see their Form ADV and brochure which can be found at Investment Advisor Public Disclosure website(https://adviserinfo.sec.gov/).This material is distributed for informational purposes only and intended solely for Insigneo Advisory Services, LLC, (“IAS” or “Insigneo”) an Securities Exchange Commission(“SEC”) investment adviser’s clientele, potential customers, and/or other parties to whom Insigneo chooses to share such information.  The discussions and opinions in thisdocument (or “Presentation”) are intended for general informational purposes only, and are not intended to provide investment advice and there is no guarantee that the opinionsexpressed herein will be valid beyond the date of this document.  The information presented in this Presentation is not intended to be used as a general guide to investing, or as asource of any specific recommendation, and makes no implied or expressed recommendations concerning the manner in which clients’ accounts should or would be handled, asappropriate strategies depend on the client’s specific objectives.  This does not constitute an offer or solicitation with respect to the purchase or sale of any security in anyjurisdiction in which such an offer or solicitation is not authorized or to any person to whom it would be unlawful to make such an offer or solicitation.  This material is basedupon information which we consider to be reliable, but we do not represent that such information is accurate or complete, and it should not be relied upon as such.  Anyhistorical information is as of the date stated.This Presentation may include forward-looking statements and all statements other than statements of historical fact are to be considered forward-looking and subjective(including words such as “believe,” “estimate,” “anticipate,” “may,” “will,” “should,” and “expect”).  Although Insigneo believes that the expectations reflected in such forward-looking statements are reasonable, it can provide no assurance that such expectations will prove to be correct.  Many factors including changing market conditions and globalpolitical and economic events could cause actual outcomes, results, or performance to differ materially from those discussed in such forward-looking statements.  Insigneo shallnot be responsible for the consequences of reliance upon any opinion or statements contained herein, and expressly disclaims any liability, including incidental or consequentialdamages, arising from any errors, omissions, or misuse.
                """,
                        style={"columnCount": 3},
                    ),
                    footer,
                ]
            ),
            ddk.Page(
                [
                    html.H2("DISCLAIMERS"),
                    html.P(
                        """
                While taken from sources deemed to be accurate, Insigneo makes no representations regarding the accuracy of the information in this document and certain information is
based on third-party sources believed to be reliable, but has not been independently verified and its accuracy or completeness cannot be guaranteed. The results portrayed are
estimated, unaudited and subject to adjustment. Also, the net results reflect the reinvestment of dividends and other earnings and the deduction of costs of execution and
management fees. Particular investors’ returns will vary from the historical performance due various factors including, but not limited to timing of withdrawals and start date in
using the referenced strategy. Past performance is no indication of future results. Inherent in any investment is the potential for loss. All information is provided for
informational purposes only and should not be deemed as a recommendation to buy the securities mentioned. A complete listing of all investments and performance by
Insigneo is available upon request.
Conflicts of Interest: Insigneo or Insigneo Financial Group, unless the specific context otherwise requires, typically and collectively refers to the Financial Industry Regulatory
Authority (”FINRA”) member broker dealer, Insigneo Securities, LLC and two affiliated Securities Exchange Commission (“SEC”) investment advisers, Insigneo Wealth Advisors,
LLC and Insigneo Advisory Services, LLC. Security products are offered and conducted through Insigneo Securities, LLC and advisory products and services are offered through
Insigneo Wealth Advisors, LLC or Insigneo Advisory Services, LLC. The referenced entities are under common ownership and share certain employees and office arrangements.
Investment advisory representatives of IAS are dually associated with affiliated entities and receive additional compensation related to advisory activities, which creates a
disclosable conflict. Please see IAS’ Form ADV Part 2A “Brochure” and your individual advisory representatives Form ADV Part 2B “Supplement” for further details.
This information is highly confidential and intended for review by the recipient only. The information should not be disseminated or be made available for public use or to any
other source without the express written authorization of Insigneo. Distribution of this document is prohibited in any jurisdiction where dissemination of such documents may be
unlawful. Please contact your investment adviser, accountant, and/or attorney for advice appropriate to your specific situation.
This information is highly confidential and intended for review by the recipient only. The information should not be disseminated or be made available for public use or to any
other source without the express written authorization of Insigneo. Distribution of this document is prohibited in any jurisdiction where dissemination of such documents may be
unlawful. Please contact your investment adviser, accountant, and/or attorney for advice appropriate to your specific situation.
Gross of fees performance: Performance results do not reflect the deduction of investment advisory fees and other expenses. Actual performance results will be reduced by
the investment advisory fees and expenses that you would pay. For example, if $100,000 were invested and experienced a 4% annual return compounded monthly for 10 years,
its ending value, without giving effect to the deduction of advisory fees, would be $149,083 with a compounded annual return of 4.07%. If an advisory fee of 0.25% of the
average market value of the account were deducted monthly for the 10-year period, the compounded annual return would be 3.82% and the ending dollar value would be
$145,414. For a description of all fees, costs and expenses, please refer to Insigneo’s Form ADV Part 2A, which is available upon request. The figures refer to the past and past
performance is not a reliable indicator of future results.
Hypothetical (simulated) performance: The performance forecasted is hypothetical, or back-tested performance. It is not actual performance. This performance is for
illustrative purposes only, and should not be used to predict future performance. Performance shown is based on current asset allocations, which may not represent past asset
allocations had these portfolios existed during the time periods shown. Asset allocations are subject to change without notice. Past performance is no guarantee of future performance. Hypothetical performance results have certain inherent limitations. They include: 1) They are prepared with the benefit of hindsight; 2) Unlike an actual performance record,
these results do not represent actual investment performance or trading and do not demonstrate Insigneo’s ability to manage money; 3) Insigneo did not recommend the
models used in the hypothetical portfolios for any clients during the period shown, and no clients invested money in accounts offered by Insigneo in accordance with those
strategies; 4) The results actual clients might have achieved would have differed from those shown because of differences in market conditions and in the timing and amounts of
their investments; and 5) Because the trades were not actually executed, the results may have under- or over-compensated for the impact, if any, of certain market factors, such
as the effect of limited trading liquidity. No representation is made that any client will or is likely to achieve profits or losses similar to those shown.
Diversification strategies do not ensure a profit and do not protect against losses in declining markets.
                """,
                        style={"columnCount": 3},
                    ),
                    html.P(
                        """
                Insigneo Advisory Services, LLC
777 Brickell Avenue
10th Floor
Miami, FL 33131
(P)(305) 373-9000
(Email) compliance_advisory@insigneo.com
                """,
                        style={"columnCount": 1},
                    ),
                    footer,
                ]
            )]
    
    elif business == 'Brokerage':
        return [ddk.Page(
                [
                    html.H2("DISCLAIMERS"),
                    html.P(
                        """
                This material is intended only to facilitate general discussions and is not intended as a source of any specific recommendation for a specific individual. Please consult with your account executive or financial advisor if any specific recommendation made herein is right for you.

This does not constitute an offer or solicitation with respect to the purchase or sale of any security in any jurisdiction in which such an offer or solicitation is not authorized or to any person to whom it would be unlawful to make such an offer or solicitation. . Brokerage and investment advisory account investments are subject to market risk including loss of principal. Insigneo Securities, LLC (Insigneo)) is a broker/dealer registered with the U.S Securities and Exchange Commission (SEC) and a member of the Financial Industry Regulatory Authority (FINRA) and Securities Investors Protection Corporation (SIPC). Insigneo is affiliated to two U.S. registered investment advisors, Insigneo Wealth Advisors, LLC (IWA) and Insigneo Advisory Services, LLC (IAS). Collectively, we refer to Insigneo and IAS as the Insigneo Financial Group. To learn more about their business, including their conflicts of interest and compensation practices for the Broker Dealer please go to www.insigneo.com/en/disclosures and any conflicts related to their advisory services, please see their Form ADV and brochure which can be found at Investment Advisor Public Disclosure website (https://adviserinfo.sec.gov/).
""",
                    ),
                    footer,
                ]
            )]
    else:
        return [business]
  