import pandas as pd

def tidyTimeseriesDf(timeseriesDf,descriptionDf,valueName):
    df = timeseriesDf.melt(id_vars=["Date"], 
        var_name="ISIN", 
        value_name=valueName).merge(descriptionDf[['ISIN','Sub Asset Class','Benchmark','Fund Name']], left_on='ISIN', right_on='ISIN') 
    return df


def PortfolioHoldingsTable(df):
    # Get rowspans for column 0 (Class) as tuple of (start_index, end_index)
    class_spans_ranges = np.where(df.iloc[:, 0].ne(df.iloc[:, 0].shift()))[0]
    bodies = []

    # Add row header
    bodies.append(
        html.Thead(
            [
                html.Td(
                    i,
                    style={
                        "fontWeight": "bold",
                        "width": w,
                        "padding": "0px 0px 5px 0px",
                        "text-align": ta,
                    },
                )
                for i, w, ta in zip(
                    ["" if i < 3 else col for i, col in enumerate(df.columns)],
                    ["3%", "3%", "9%", "10%", "41%", "21%", "11%"],
                    ["left"] * (len(df.columns) - 1) + ["right"],
                )
            ]
        )
    )

    for r in range(len(class_spans_ranges) - 1):
        # Break the df into subdfs by column 0 (Class)
        # Each class will be added as an html.Tbody to bodies
        range_ = class_spans_ranges[r], class_spans_ranges[r + 1]
        subdf = df.loc[range_[0] : range_[1]]
        # Get rowspans for column 2
        clsfn_spans = np.diff(
            np.where(subdf.iloc[:, 2].ne(subdf.iloc[:, 2].shift()))[0]
        )

        # Create first row for each column 0 section
        row1 = [
            html.Tr(
                [
                    html.Td(
                        subdf.loc[class_spans_ranges[r], df.columns[0]],
                        rowSpan="{}".format(np.diff(range_)[0]),
                        style={
                            "transform": "rotate(-90.0deg)",
                            "padding": "0px 0px",
                            "text-align": "center",
                        },
                    ),
                    html.Td(
                        subdf.loc[class_spans_ranges[r], df.columns[1]],
                        rowSpan="{}".format(np.diff(range_)[0]),
                        style={"transform": "rotate(-90.0deg)", "padding": "0px 0px"},
                    ),
                    html.Td(
                        subdf.loc[class_spans_ranges[r], df.columns[2]],
                        rowSpan="{}".format(clsfn_spans[0]),
                        style={"padding": "0 0 0 5px"},
                    ),
                ]
                + [
                    html.Td(
                        subdf.iloc[0, j],
                        style={
                            "padding": p,
                            "background-color": "white",
                            "color": "black",
                            "text-align": ta,
                            "font-size": "11px",
                        },
                    )
                    for j, ta, p in zip(
                        range(3, len(subdf.columns)),
                        ["left"] * (len(subdf.columns) - 4) + ["right"],
                        [
                            "0 5px" if col != "Benchmark" else "0"
                            for col in subdf.columns[3:]
                        ],
                    )
                ],
                style={
                    "background-color": "var(--colorway-{})".format(r),
                    "color": "white",
                },
            )
        ]

        # Create subsequent rows for each Class
        # If the first row needs a multi row span:
        if clsfn_spans[0] > 1:
            row1.extend(
                [
                    html.Td(
                        subdf.iloc[1, j],
                        style={"padding": p, "text-align": ta, "font-size": "11px"},
                    )
                    for j, ta, p in zip(
                        range(3, len(subdf.columns)),
                        ["left"] * (len(subdf.columns) - 4) + ["right"],
                        [
                            "0 5px" if col != "Benchmark" else "0"
                            for col in subdf.columns[3:]
                        ],
                    )
                ]
            )

        for idx, clsfn_span in enumerate(clsfn_spans[1:]):
            rows = []
            toprow = html.Tr(
                [
                    html.Td(
                        subdf.iloc[sum(clsfn_spans[: idx + 1]), 2],
                        rowSpan="{}".format(clsfn_span),
                        style={
                            "padding": "0 5px",
                            "background-color": "var(--colorway-{})".format(r),
                            "color": "white",
                        },
                    )
                ]
                + [
                    html.Td(
                        subdf.iloc[sum(clsfn_spans[: idx + 1]), j],
                        style={"padding": p, "text-align": ta, "font-size": "11px"},
                    )
                    for j, ta, p in zip(
                        range(3, len(subdf.columns)),
                        ["left"] * (len(subdf.columns) - 4) + ["right"],
                        [
                            "0 5px" if col != "Benchmark" else "0"
                            for col in subdf.columns[3:]
                        ],
                    )
                ]
            )
            rows.append(toprow)
            for idx2 in range(1, clsfn_span):
                rows.append(
                    html.Tr(
                        [
                            html.Td(
                                subdf.iloc[sum(clsfn_spans[: idx + 1]) + idx2, j],
                                style={
                                    "padding": p,
                                    "text-align": ta,
                                    "font-size": "11px",
                                },
                            )
                            for j, ta, p in zip(
                                range(3, len(subdf.columns)),
                                ["left"] * (len(subdf.columns) - 4) + ["right"],
                                [
                                    "0 5px" if col != "Benchmark" else "0"
                                    for col in subdf.columns[3:]
                                ],
                            )
                        ]
                    )
                )
            row1.extend(rows)

        bodies.append(html.Tbody(row1))

    # Add last row:
    bodies.append(
        html.Tbody(
            [
                html.Tr(
                    [
                        html.Td(
                            df.iloc[len(df) - 1, j],
                            style={
                                "padding": "0 5px",
                                "text-align": ta,
                                "font-size": "11px",
                                "border-bottom": "none",
                            },
                        )
                        for j, ta in zip(
                            range(len(df.columns)),
                            ["left"] * (len(df.columns) - 1) + ["right"],
                        )
                    ]
                )
            ]
        )
    )

    return html.Table(bodies)
