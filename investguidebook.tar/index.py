import dash
from dash.dependencies import Input, Output
import dash_design_kit as ddk
from dash import dcc, html, dash_table

from app import app, snap
import pages
server = app.server
celery_instance = snap.celery_instance

app.layout = ddk.App(show_editor=True, children=[
    ddk.Header([
        dcc.Link(
            ddk.Logo(src=app.get_relative_path('/assets/logo.png')),
            href=app.get_relative_path('/')
        ),
        ddk.Title('Analytics'),
        ddk.Menu([
            dcc.Link(
                href=app.get_relative_path('/'),
                children='Home'
            ),
            dcc.Link(
                href=app.get_relative_path('/fundReviews'),
                children='Investment guidebook funds'
            ),
            dcc.Link(
                href=app.get_relative_path('/portfolioBuilder'),
                children='Portfolio Builder'
            ),
            dcc.Link(
                href=app.get_relative_path('/archive'),
                children='Archive'
            )
        ])
    ]),
    dcc.Location(id='url'),
    html.Div(id='content')
])


@app.callback(
    Output('content', 'children'),
    [Input('url', 'pathname')])
def display_content(pathname):
    page_name = app.strip_relative_path(pathname)
    if not page_name:  # None or ''
        return pages.home.layout()
    elif page_name == 'archive':
        return pages.archive.layout()
    elif page_name == 'fundReviews':
        return pages.fundReviews.layout()
    elif page_name == 'portfolioBuilder':
        return pages.portfolioBuilder.layout()
    elif page_name.startswith("snapshot-"):
        return pages.snapshot.layout(page_name)
    elif page_name == 'dev':
        # Display a report with mock data for development purposes
        return pages.snapshot.report()
    else:
        return '404'


if __name__ == '__main__':
    app.run_server(debug=True)
