import dash
from dash.dependencies import Input, Output
import dash_design_kit as ddk
from dash import dcc, html
import pandas as pd
import numpy as np
import plotly.express as px

from app import app

from data import utilityFunctions

timeseriesDf = pd.read_csv(
    "./data/focusListTimeseries.csv", engine="python"
)

snapshotDf = pd.read_csv(
    "./data/performanceSnapshot.csv", encoding="ISO-8859-1", engine="python"
)

describeDf = pd.read_csv('./data/descriptiveStats.csv')

tidyTimeseries = utilityFunctions.tidyTimeseriesDf(timeseriesDf,describeDf,'NAV')
snapshotDf = snapshotDf.merge(describeDf[['ISIN','Sub Asset Class','Benchmark','Fund Name']], left_on='ISIN', right_on='ISIN')

timeseriesChgDf = timeseriesDf.set_index('Date').pct_change(1)
timeseriesIndexDf = timeseriesDf.set_index('Date').pct_change(1)

for i in timeseriesChgDf.columns:
    timeseriesIndexDf[i] = 100*np.exp(np.nan_to_num(timeseriesChgDf[i].cumsum()))

tidyTimeseriesIndexDf = utilityFunctions.tidyTimeseriesDf(timeseriesIndexDf.reset_index(),describeDf,'Indexed')

timeseriesChgDf = timeseriesDf.set_index('Date').pct_change(5)
tidyTimeseriesChgDf = utilityFunctions.tidyTimeseriesDf(timeseriesChgDf.reset_index(),describeDf,'Weekly Change')


def layout():
    return html.Div([

    ddk.Card(
        width=100,
        children=[
            ddk.CardHeader(
                title='Sub Asset Class',
                children=dcc.Dropdown(
                    id='filterSummary',
                    options=[
                        {'label': i, 'value': i}
                        for i in describeDf['Sub Asset Class'].unique()
                    ],
                    multi = False,
                    value='Large Cap Core',
                    clearable=False
                )),
                ddk.CardHeader(
                title='Timeseries Type',
                children=dcc.Dropdown(
                    id='valueType',
                    options=[
                        {'label': i, 'value': i}
                        for i in ['NAV','Indexed','Weekly Change']
                    ],
                    multi = False,
                    value='NAV',clearable=False)
                
                ,
            ),
            ddk.CardHeader(
        #width=100,
        children=[
            ddk.DataTable(
                id='dataTable',
                style_table={
                    'maxHeight': '500px',
                    'overflowY': 'scroll'
                },
                #style_as_list_view=True
            )
        ]
    ),
            ddk.Graph(id='historical-summary')
        ]
    ),
])


@app.callback([Output('dataTable', 'data'),Output('dataTable', 'columns')],
 [Input('filterSummary', 'value')])
def update_graph(value):
    dff = snapshotDf.loc[snapshotDf['Sub Asset Class']==value][['Fund Name', 'Performance From Inception to Yesterday',
       '1 Month Performance to Yesterday', '3 Month Performance to Yesterday',
       '6 Month Performance to Yesterday', '1 Year Performance to Yesterday',
       '3 Year Performance to Yesterday', '5 Year Performance to Yesterday']]
    dff = dff.set_index('Fund Name').transpose().reset_index()

    return dff.to_dict('records'),[{"name": i, "id": i} for i in dff.columns]

@app.callback(Output('historical-summary', 'figure'), [Input('filterSummary', 'value'),Input('valueType', 'value')])
def update_graph(value,series):
    if series == 'NAV':
        df = tidyTimeseries.loc[tidyTimeseries['Sub Asset Class']==value]
        fig = px.line(df, x='Date', y='NAV',color='Fund Name')
    if series == 'Indexed':
        df = tidyTimeseriesIndexDf.loc[tidyTimeseriesIndexDf['Sub Asset Class']==value]
        fig = px.line(df, x='Date', y='Indexed',color='Fund Name')
    if series == 'Weekly Change':
        df = tidyTimeseriesChgDf.loc[tidyTimeseriesChgDf['Sub Asset Class']==value]
        fig = px.line(df, x='Date', y='Weekly Change',color='Fund Name')
    return fig