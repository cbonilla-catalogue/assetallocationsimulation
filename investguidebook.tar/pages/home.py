import dash
from dash.dependencies import Input, Output, State
import dash_design_kit as ddk
from dash import dcc, html, dash_table

from app import app, snap
from .import tasks


def layout():
    return html.Div([
        ddk.ControlCard([
            ddk.ControlItem(dcc.Input(id='temperature', value=0), label='Temperature', width=30),
            ddk.ControlItem(dcc.Input(id='pressure', value=0), label='Pressure', width=30),
            ddk.ControlItem(dcc.Input(id='humidity', value=0), label='humidity', width=40),
            html.Button('Run', id='run'),
            html.Div(id='status')
        ], orientation='horizontal'),

        # You may also choose to display intermediate results here
        # that provide some quick feedback before the snapshot
        # Or, you could even display the snapshot results here as per
        # the "Background Task Queue"
        # sample application
    ])

