import dash
import dash_design_kit as ddk
import dash_bootstrap_components as dbc
from dash import dash_table, dcc, html
from dash.dependencies import Input, Output

import pandas as pd

# df_fund_facts = pd.read_csv('./static_data/MutualFundDB_upload.csv',encoding = "ISO-8859-1",engine='python')
df_fund_facts = pd.read_csv(
    "./static_data/MutualFundDB_upload.csv", engine="python", encoding="cp1252"
)

#df_fund_facts["link"] = df_fund_facts["ISIN"].apply(
#    lambda x: "https://www.google.com/search?q={0}+factsheet".format(x)
#)


def url(row):
    return "[{1}]({0})".format(row["link"], row["Name"])

df_fund_facts

app = dash.Dash(__name__)
server = app.server  # expose server variable for Procfile

DatabaseTable = ddk.DataTable(
    id="fund_table",
    columns=[
        {"name": i, "id": i, "type": "text", "presentation": "markdown"}
        for i in df_fund_facts.drop(columns=["Fund Family"]).columns
    ],
    style_cell={"fontSize": 14, "font-family": "sans-serif", "textAlign": "left"},
    page_current=0,
    page_size=19,
    page_action="custom",
    # filter_action='custom',
    # filter_query='',
    sort_action="custom",
    sort_mode="multi",
    sort_by=[],
    export_format="csv",
    # fixed_columns={'headers': True, 'data': 1},
    style_table={"overflowX": "auto"},
    style_data_conditional=[
        {"if": {"row_index": "odd"}, "backgroundColor": "rgb(232, 236, 238)"},
    ],
    style_header={"backgroundColor": "rgb(230, 230, 230)", "fontWeight": "bold"},
)

controls = [
    ddk.ControlItem(
        dcc.Dropdown(
            id="fund_family",
            options=[
                {"label": i, "value": i} for i in df_fund_facts["Fund Family"].unique()
            ],
            multi=True,
        ),
        label="Fund Manager",
        width=25,
    ),
    ddk.ControlItem(
        dcc.Dropdown(
            id="asset_class",
            options=[
                {"label": i, "value": i}
                for i in df_fund_facts["Asset Class"].dropna().unique()
            ],
            multi=True,
        ),
        label="Asset Class",
        width=25,
    ),
    ddk.ControlItem(
        dcc.Dropdown(
            id="investment_subasset",
            options=[
                {"label": i, "value": i}
                for i in df_fund_facts["Sub Asset Class"].dropna().unique()
            ],
            multi=True,
        ),
        label="Sub Asset Class",
        width=25,
    ),
    ddk.ControlItem(
        dcc.Dropdown(
            id="investment_region",
            options=[
                {"label": i, "value": i}
                for i in df_fund_facts["Investment Area"].dropna().unique()
            ],
            multi=True,
        ),
        label="Investment Area",
        width=25,
    ),
    ddk.ControlItem(
        dbc.Input(
            id="ISIN_search",
            type="search",
            placeholder="type to search",
        ),
        label="ISIN",
        width=25,
    ),
    ddk.ControlItem(
        dbc.Input(
            id="CUSIP_search",
            type="search",
            placeholder="type to search",
        ),
        label="CUSIP",
        width=25,
    ),
]

menu = ddk.Menu(
    [
        ddk.CollapsibleMenu(
            title="Investment Guidebooks",
            default_open=False,
            children=[
                dcc.Link(
                    "Offshore",
                    href="https://hencorp.sharepoint.com/sites/InsigneoTrading/Shared%20Documents/Mutual%20Funds/Investment%20Guidebook%204Q-2021.pdf",
                    refresh=True,
                ),
                dcc.Link(
                    "Factsheets",
                    href="https://www.fundinfo.com/en/LandingPage?apiKey=7dd308ef-8b1d-4870-bf40-4cf93ffaa1ed",
                    refresh=True,
                ),
            ],
        ),
        dcc.Link(
            "Insigneo+",
            href="https://hencorp.sharepoint.com/sites/InsigneoTrading/SitePages/mutual-funds.aspx",
            refresh=True,
        ),
    ]
)


app.layout = ddk.App(
    [
        ddk.Header(
            [
                ddk.Logo(src=app.get_asset_url("logoNew.png")),
                ddk.Title("Mutual Fund Database"),
                menu,
            ]
        ),
        ddk.ControlCard(controls, width=100, orientation="horizontal"),
        ddk.ControlCard(
            ddk.ControlItem(
                dbc.Input(
                    placeholder="start typing to search",
                    type="search",
                    id="search_string",
                ),
                label="Fund Name",
            ),
            width=100,
            orientation="horizontal",
        ),
        ddk.Card(width=100, children= dcc.Link(
                    "Click here to search for updated factsheets",
                    href="https://www.fundinfo.com/en/LandingPage?apiKey=7dd308ef-8b1d-4870-bf40-4cf93ffaa1ed",
                    refresh=True,
                )),
        ddk.Card(width=100, children=DatabaseTable),
    ]
)


@app.callback(
    Output("fund_table", "data"),
    [
        Input("fund_table", "page_current"),
        Input("fund_table", "page_size"),
        Input("fund_table", "sort_by"),
        Input("asset_class", "value"),
        Input('investment_subasset','value'),
        Input("fund_family", "value"),
        Input("investment_region", "value"),
        Input("ISIN_search", "value"),
        Input("CUSIP_search", "value"),
        Input("search_string", "value"),
    ],
)
def update_table(
    page_current,
    page_size,
    sort_by,
    asset_class,
    investment_subasset,
    fund_family,
    investment_region,
    ISIN_search,
    CUSIP_search,
    search_string,
):
    
    if len(sort_by):
        dff = df_fund_facts.sort_values(
            [col["column_id"] for col in sort_by],
            ascending=[col["direction"] == "asc" for col in sort_by],
            inplace=False,
        )
    else:
        # No sort is applied
        dff = df_fund_facts
        
    #dff["Name"] = dff.apply(url, axis=1)

    if search_string is not None:
        dff = dff.loc[
            dff["Name"].str.contains(search_string, na=False, regex=False, case=False)
        ]
    if ISIN_search is not None:
        dff = dff.loc[
            dff["ISIN"].str.contains(ISIN_search, na=False, regex=False, case=False)
        ]
    if CUSIP_search is not None:
        dff = dff.loc[
            dff["CUSIP"].str.contains(CUSIP_search, na=False, regex=False, case=False)
        ]
    if asset_class is None:
        asset_class = dff["Asset Class"].unique()
    if asset_class == []:
        asset_class = dff["Asset Class"].unique()
    if investment_subasset is None:
        investment_subasset = dff["Sub Asset Class"].unique()
    if investment_subasset == []:
        investment_subasset = dff["Sub Asset Class"].unique()
    if fund_family is None:
        fund_family = dff["Fund Family"].unique()
    if fund_family == []:
        fund_family = dff["Fund Family"].unique()
    if investment_region is None:
        investment_region = dff["Investment Area"].unique()
    if investment_region == []:
        investment_region = dff["Investment Area"].unique()

    print(investment_subasset)
    # if fund_market is None:
    #    fund_market = dff['Investment Area'].unique()
    asset_class_filter = dff["Asset Class"].isin(asset_class)
    investment_subasset_filter = dff["Sub Asset Class"].isin(investment_subasset)
    fund_family_filter = dff["Fund Family"].isin(fund_family)
    investment_region_filter = dff["Investment Area"].isin(investment_region)
    # market_filter = dff["Investment Area"].isin(fund_market)
    # dff = dff[asset_class_filter & fund_family_filter & market_filter]
    dff = dff[asset_class_filter & fund_family_filter & investment_region_filter & investment_subasset_filter]

    #dff["Name"] = dff.apply(url, axis=1)

    return dff.iloc[page_current * page_size : (page_current + 1) * page_size].to_dict(
        "records"
    )


if __name__ == "__main__":
    app.run_server(debug=True)
